const fs = require('fs-extra')
if (fs.existsSync('.env')) require('dotenv').config({ path: __dirname+'/.env' })


//═══════[Required Variables]════════\\
global.audio= "" ;  
global.video= "" ;
global.port =process.env.PORT
global.appUrl=process.env.APP_URL || ""                       // put your app url here,
global.email ="ahmedsohail2525@gmail.com"
global.location="Islamabad, Pakistan."


global.mongodb= process.env.MONGODB_URI || "mongodb+srv://ahmi:<password>@bot.x47risl.mongodb.net/?retryWrites=true&w=majority&appName=Bot"
global.allowJids= process.env.ALLOW_JID || "null" 
global.blockJids= process.env.BLOCK_JID || "null"
global.DATABASE_URL = process.env.DATABASE_URL || ""

global.timezone= process.env.TZ || process.env.TIME_ZONE || "Asia/Karachi";
global.github=process.env.GITHUB|| "https://github.com/ahmiaf";
global.gurl  =process.env.GURL  || "https://wa.link/jc0bfl";
global.website=process.env.GURL || "https://wa.link/jc0bfl" ; 
global.THUMB_IMAGE = process.env.THUMB_IMAGE || process.env.IMAGE || "https://avatars.githubusercontent.com/u/89537916?v=4" ; // SET LOGO FOR IMAGE 
global.caption = process.env.CAPTION || global.caption || "Power by Ahmed" 


global.devs = "923138888390" // Developer Contact
global.sudo = process.env.SUDO ? process.env.SUDO.replace(/[\s+]/g, '') : "null";
global.owner= process.env.OWNER_NUMBER ? process.env.OWNER_NUMBER.replace(/[\s+]/g, '') : "923138888390";




//========================= [ BOT SETTINGS ] =========================\\
global.style = process.env.STYLE   || '2'  // put '1' to "5" here to check bot styles
global.flush = process.env.FLUSH   || "false"; // Make it "true" if bot not responed
global.gdbye = process.env.GOODBYE || "true"; 
global.wlcm  = process.env.WELCOME || "true";  // Make it "false" for disable WELCOME 

global.warncount = process.env.WARN_COUNT || 3
global.disablepm = process.env.DISABLE_PM || "false"
global.disablegroup = process.env.DISABLE_GROUPS || "false", // disable bot in groups when public mode

global.MsgsInLog = process.env.MSGS_IN_LOG|| "false" // "true"  to see messages , "log" to show logs , "false" to hide logs messages
global.userImages= process.env.USER_IMAGES || "" // "text" // set Image/video urls here
global.waPresence= process.env.WAPRESENCE ||  "null" ; // 'unavailable' | 'available' | 'composing' | 'recording' | 'paused'


//========================= [ AUTO READ MSGS & CMDS ] =========================\\
global.readcmds = process.env.READ_COMMAND || "false"
global.readmessage = process.env.READ_MESSAGE || "false"
global.readmessagefrom = process.env.READ_MESSAGE_FROM || "null,923xxxxxxxx";


//========================= [ AUTO SAVE & READ STATUS ] =========================\\
global.read_status = process.env.AUTO_READ_STATUS || "false"
global.save_status = process.env.AUTO_SAVE_STATUS || "false"
global.save_status_from =  process.env.SAVE_STATUS_FROM  || "null,923xxxxxxxx";
global.read_status_from =  process.env.READ_STATUS_FROM  ||  "923138888390,923xxxxxxxx";

global.api_smd = "https://api-smd.onrender.com" //  || "https://api-smd-1.vercel.app" // expires
global.scan = "https://suhail-md-vtsf.onrender.com";


global.SESSION_ID = process.env.SESSION_ID ||  "SUHAIL_17_01_06_18_ewogICJjcmVkcy5qc29uIjogIntcbiAgXCJub2lzZUtleVwiOiB7XG4gICAgXCJwcml2YXRlXCI6IHtcbiAgICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgICAgXCJkYXRhXCI6IFtcbiAgICAgICAgODgsXG4gICAgICAgIDk1LFxuICAgICAgICAyMjksXG4gICAgICAgIDQ3LFxuICAgICAgICAxNSxcbiAgICAgICAgMTQzLFxuICAgICAgICAyMjgsXG4gICAgICAgIDIzMSxcbiAgICAgICAgMjgsXG4gICAgICAgIDEwMCxcbiAgICAgICAgODMsXG4gICAgICAgIDYxLFxuICAgICAgICAxMTMsXG4gICAgICAgIDIxMSxcbiAgICAgICAgMTg5LFxuICAgICAgICA2NCxcbiAgICAgICAgMjAyLFxuICAgICAgICAxODgsXG4gICAgICAgIDEwMyxcbiAgICAgICAgMjIwLFxuICAgICAgICA2MixcbiAgICAgICAgMTAzLFxuICAgICAgICAyNDYsXG4gICAgICAgIDIwNixcbiAgICAgICAgMjM0LFxuICAgICAgICAxODcsXG4gICAgICAgIDE1NyxcbiAgICAgICAgNTgsXG4gICAgICAgIDUyLFxuICAgICAgICA4MCxcbiAgICAgICAgMjksXG4gICAgICAgIDExMFxuICAgICAgXVxuICAgIH0sXG4gICAgXCJwdWJsaWNcIjoge1xuICAgICAgXCJ0eXBlXCI6IFwiQnVmZmVyXCIsXG4gICAgICBcImRhdGFcIjogW1xuICAgICAgICA2MyxcbiAgICAgICAgMTcsXG4gICAgICAgIDE3MSxcbiAgICAgICAgMjQyLFxuICAgICAgICAyNCxcbiAgICAgICAgMjMxLFxuICAgICAgICA5MixcbiAgICAgICAgMjQ3LFxuICAgICAgICAxMzAsXG4gICAgICAgIDI0MCxcbiAgICAgICAgMTcsXG4gICAgICAgIDE3MixcbiAgICAgICAgMzMsXG4gICAgICAgIDIxNyxcbiAgICAgICAgMTUsXG4gICAgICAgIDEzMCxcbiAgICAgICAgNjYsXG4gICAgICAgIDcyLFxuICAgICAgICAxNixcbiAgICAgICAgMTEyLFxuICAgICAgICAyMzcsXG4gICAgICAgIDEwOSxcbiAgICAgICAgMTYwLFxuICAgICAgICA2MSxcbiAgICAgICAgMTM0LFxuICAgICAgICAyNDMsXG4gICAgICAgIDE4OCxcbiAgICAgICAgOTksXG4gICAgICAgIDExNCxcbiAgICAgICAgNDEsXG4gICAgICAgIDE0NyxcbiAgICAgICAgMjBcbiAgICAgIF1cbiAgICB9XG4gIH0sXG4gIFwicGFpcmluZ0VwaGVtZXJhbEtleVBhaXJcIjoge1xuICAgIFwicHJpdmF0ZVwiOiB7XG4gICAgICBcInR5cGVcIjogXCJCdWZmZXJcIixcbiAgICAgIFwiZGF0YVwiOiBbXG4gICAgICAgIDk2LFxuICAgICAgICAxMDMsXG4gICAgICAgIDIyNixcbiAgICAgICAgMjMyLFxuICAgICAgICAxMzAsXG4gICAgICAgIDczLFxuICAgICAgICAxNzcsXG4gICAgICAgIDk1LFxuICAgICAgICAxNDYsXG4gICAgICAgIDI1LFxuICAgICAgICAxMDcsXG4gICAgICAgIDI1MSxcbiAgICAgICAgMTg3LFxuICAgICAgICAyMzEsXG4gICAgICAgIDIzMyxcbiAgICAgICAgMTI4LFxuICAgICAgICAxMTAsXG4gICAgICAgIDMwLFxuICAgICAgICA4NixcbiAgICAgICAgMTYwLFxuICAgICAgICAxMTAsXG4gICAgICAgIDI0NSxcbiAgICAgICAgMjAzLFxuICAgICAgICAxMDUsXG4gICAgICAgIDIyNyxcbiAgICAgICAgMTgzLFxuICAgICAgICAxMzcsXG4gICAgICAgIDIxNSxcbiAgICAgICAgMTM4LFxuICAgICAgICAxNDIsXG4gICAgICAgIDUwLFxuICAgICAgICA5NFxuICAgICAgXVxuICAgIH0sXG4gICAgXCJwdWJsaWNcIjoge1xuICAgICAgXCJ0eXBlXCI6IFwiQnVmZmVyXCIsXG4gICAgICBcImRhdGFcIjogW1xuICAgICAgICAyNDcsXG4gICAgICAgIDIxNyxcbiAgICAgICAgMTYwLFxuICAgICAgICAyMDksXG4gICAgICAgIDE3MixcbiAgICAgICAgMTI0LFxuICAgICAgICAyMDAsXG4gICAgICAgIDc4LFxuICAgICAgICAxODcsXG4gICAgICAgIDIyNyxcbiAgICAgICAgMTc0LFxuICAgICAgICAyMDAsXG4gICAgICAgIDI1MixcbiAgICAgICAgODgsXG4gICAgICAgIDI0MSxcbiAgICAgICAgODQsXG4gICAgICAgIDIzLFxuICAgICAgICAyNTUsXG4gICAgICAgIDEyLFxuICAgICAgICAyNDIsXG4gICAgICAgIDI0MyxcbiAgICAgICAgMzksXG4gICAgICAgIDY3LFxuICAgICAgICA0NixcbiAgICAgICAgMTA2LFxuICAgICAgICA4OCxcbiAgICAgICAgODcsXG4gICAgICAgIDE4OCxcbiAgICAgICAgNjMsXG4gICAgICAgIDAsXG4gICAgICAgIDc2LFxuICAgICAgICA0NlxuICAgICAgXVxuICAgIH1cbiAgfSxcbiAgXCJzaWduZWRJZGVudGl0eUtleVwiOiB7XG4gICAgXCJwcml2YXRlXCI6IHtcbiAgICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgICAgXCJkYXRhXCI6IFtcbiAgICAgICAgMTg0LFxuICAgICAgICAxMjcsXG4gICAgICAgIDIxLFxuICAgICAgICAxODAsXG4gICAgICAgIDEwNyxcbiAgICAgICAgMTMsXG4gICAgICAgIDIyNSxcbiAgICAgICAgMTksXG4gICAgICAgIDEyNCxcbiAgICAgICAgMTEyLFxuICAgICAgICA4MSxcbiAgICAgICAgNTYsXG4gICAgICAgIDE3MCxcbiAgICAgICAgMjMxLFxuICAgICAgICAyMjIsXG4gICAgICAgIDIzMSxcbiAgICAgICAgMTg3LFxuICAgICAgICAzNSxcbiAgICAgICAgMTUyLFxuICAgICAgICA0OCxcbiAgICAgICAgNDgsXG4gICAgICAgIDE0NixcbiAgICAgICAgMTUxLFxuICAgICAgICAyMjMsXG4gICAgICAgIDIzOSxcbiAgICAgICAgMjE5LFxuICAgICAgICAzLFxuICAgICAgICAyMzcsXG4gICAgICAgIDUsXG4gICAgICAgIDkzLFxuICAgICAgICAxNzgsXG4gICAgICAgIDg4XG4gICAgICBdXG4gICAgfSxcbiAgICBcInB1YmxpY1wiOiB7XG4gICAgICBcInR5cGVcIjogXCJCdWZmZXJcIixcbiAgICAgIFwiZGF0YVwiOiBbXG4gICAgICAgIDIyNSxcbiAgICAgICAgMTEyLFxuICAgICAgICAxOTQsXG4gICAgICAgIDIzNixcbiAgICAgICAgMTg0LFxuICAgICAgICAxNTIsXG4gICAgICAgIDQwLFxuICAgICAgICAyMjUsXG4gICAgICAgIDMzLFxuICAgICAgICA1MCxcbiAgICAgICAgMjI2LFxuICAgICAgICAyMDMsXG4gICAgICAgIDkyLFxuICAgICAgICAyMzcsXG4gICAgICAgIDEyMixcbiAgICAgICAgMjI2LFxuICAgICAgICAzOCxcbiAgICAgICAgMzgsXG4gICAgICAgIDE4MyxcbiAgICAgICAgMTQsXG4gICAgICAgIDIxNCxcbiAgICAgICAgMTYsXG4gICAgICAgIDE1OCxcbiAgICAgICAgNjEsXG4gICAgICAgIDQ5LFxuICAgICAgICAxMDgsXG4gICAgICAgIDQxLFxuICAgICAgICAyNTEsXG4gICAgICAgIDE3LFxuICAgICAgICAyMDAsXG4gICAgICAgIDExMSxcbiAgICAgICAgMTA1XG4gICAgICBdXG4gICAgfVxuICB9LFxuICBcInNpZ25lZFByZUtleVwiOiB7XG4gICAgXCJrZXlQYWlyXCI6IHtcbiAgICAgIFwicHJpdmF0ZVwiOiB7XG4gICAgICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgICAgICBcImRhdGFcIjogW1xuICAgICAgICAgIDI0OCxcbiAgICAgICAgICAyMzcsXG4gICAgICAgICAgMjIyLFxuICAgICAgICAgIDEwMyxcbiAgICAgICAgICA2LFxuICAgICAgICAgIDE0NixcbiAgICAgICAgICAyMzIsXG4gICAgICAgICAgMTc2LFxuICAgICAgICAgIDIxLFxuICAgICAgICAgIDEyMSxcbiAgICAgICAgICA3MSxcbiAgICAgICAgICA1NixcbiAgICAgICAgICAxOTcsXG4gICAgICAgICAgMjAyLFxuICAgICAgICAgIDUzLFxuICAgICAgICAgIDEwNSxcbiAgICAgICAgICA3OCxcbiAgICAgICAgICAyNDIsXG4gICAgICAgICAgMjQxLFxuICAgICAgICAgIDg4LFxuICAgICAgICAgIDI0OCxcbiAgICAgICAgICAxNTYsXG4gICAgICAgICAgMTU5LFxuICAgICAgICAgIDE5NyxcbiAgICAgICAgICAxNDYsXG4gICAgICAgICAgNjgsXG4gICAgICAgICAgODUsXG4gICAgICAgICAgMjA1LFxuICAgICAgICAgIDgxLFxuICAgICAgICAgIDYyLFxuICAgICAgICAgIDEzMixcbiAgICAgICAgICA2NFxuICAgICAgICBdXG4gICAgICB9LFxuICAgICAgXCJwdWJsaWNcIjoge1xuICAgICAgICBcInR5cGVcIjogXCJCdWZmZXJcIixcbiAgICAgICAgXCJkYXRhXCI6IFtcbiAgICAgICAgICAyMTUsXG4gICAgICAgICAgMjExLFxuICAgICAgICAgIDcsXG4gICAgICAgICAgMTMsXG4gICAgICAgICAgMjE1LFxuICAgICAgICAgIDIwNyxcbiAgICAgICAgICA3NixcbiAgICAgICAgICAxNzYsXG4gICAgICAgICAgMTY1LFxuICAgICAgICAgIDE0NixcbiAgICAgICAgICA1NyxcbiAgICAgICAgICAxNTksXG4gICAgICAgICAgMjA0LFxuICAgICAgICAgIDM2LFxuICAgICAgICAgIDEwMixcbiAgICAgICAgICAxMjEsXG4gICAgICAgICAgMTEzLFxuICAgICAgICAgIDksXG4gICAgICAgICAgMjA2LFxuICAgICAgICAgIDExNCxcbiAgICAgICAgICAxMjksXG4gICAgICAgICAgMTgzLFxuICAgICAgICAgIDk5LFxuICAgICAgICAgIDI0OCxcbiAgICAgICAgICA2MCxcbiAgICAgICAgICAzNCxcbiAgICAgICAgICAyOSxcbiAgICAgICAgICA1MCxcbiAgICAgICAgICAxOTMsXG4gICAgICAgICAgMzAsXG4gICAgICAgICAgMTg4LFxuICAgICAgICAgIDExNlxuICAgICAgICBdXG4gICAgICB9XG4gICAgfSxcbiAgICBcInNpZ25hdHVyZVwiOiB7XG4gICAgICBcInR5cGVcIjogXCJCdWZmZXJcIixcbiAgICAgIFwiZGF0YVwiOiBbXG4gICAgICAgIDI1MCxcbiAgICAgICAgODYsXG4gICAgICAgIDI0MyxcbiAgICAgICAgMjI3LFxuICAgICAgICA2NSxcbiAgICAgICAgNDgsXG4gICAgICAgIDI4LFxuICAgICAgICAyMTUsXG4gICAgICAgIDE2MSxcbiAgICAgICAgNDQsXG4gICAgICAgIDIwNixcbiAgICAgICAgMzUsXG4gICAgICAgIDIwMCxcbiAgICAgICAgMjU0LFxuICAgICAgICAxNzQsXG4gICAgICAgIDUxLFxuICAgICAgICAyNyxcbiAgICAgICAgMTEyLFxuICAgICAgICAxNDAsXG4gICAgICAgIDYsXG4gICAgICAgIDIzMixcbiAgICAgICAgMTA0LFxuICAgICAgICAxMjEsXG4gICAgICAgIDI3LFxuICAgICAgICAxNzgsXG4gICAgICAgIDIyMCxcbiAgICAgICAgMTQwLFxuICAgICAgICAxOTYsXG4gICAgICAgIDE4NixcbiAgICAgICAgODksXG4gICAgICAgIDEyMixcbiAgICAgICAgMTUzLFxuICAgICAgICA0OCxcbiAgICAgICAgMzgsXG4gICAgICAgIDExNCxcbiAgICAgICAgMjIzLFxuICAgICAgICA2NCxcbiAgICAgICAgODMsXG4gICAgICAgIDI1MSxcbiAgICAgICAgNTMsXG4gICAgICAgIDIwLFxuICAgICAgICAyNDQsXG4gICAgICAgIDcwLFxuICAgICAgICAxMjcsXG4gICAgICAgIDc5LFxuICAgICAgICAyMDIsXG4gICAgICAgIDIzNixcbiAgICAgICAgMTY2LFxuICAgICAgICA0OCxcbiAgICAgICAgMTIyLFxuICAgICAgICAxMzIsXG4gICAgICAgIDE0NixcbiAgICAgICAgMTM2LFxuICAgICAgICAyMTMsXG4gICAgICAgIDg2LFxuICAgICAgICAzMSxcbiAgICAgICAgMjI2LFxuICAgICAgICAyMjAsXG4gICAgICAgIDIzMCxcbiAgICAgICAgMTMxLFxuICAgICAgICA4OSxcbiAgICAgICAgNDYsXG4gICAgICAgIDIzMixcbiAgICAgICAgMTMwXG4gICAgICBdXG4gICAgfSxcbiAgICBcImtleUlkXCI6IDFcbiAgfSxcbiAgXCJyZWdpc3RyYXRpb25JZFwiOiA1NCxcbiAgXCJhZHZTZWNyZXRLZXlcIjogXCJWSVlDbXNNdHhVRzhFRVlWN3doczNON3N6Z210ZVRYOWpWL3ZJL0d4SnhFPVwiLFxuICBcInByb2Nlc3NlZEhpc3RvcnlNZXNzYWdlc1wiOiBbXG4gICAge1xuICAgICAgXCJrZXlcIjoge1xuICAgICAgICBcInJlbW90ZUppZFwiOiBcIjkyMzAxNTA1MTIzMkBzLndoYXRzYXBwLm5ldFwiLFxuICAgICAgICBcImZyb21NZVwiOiB0cnVlLFxuICAgICAgICBcImlkXCI6IFwiOTgzNkY1MEUzMzc4QjNEQ0RFQjc0MzhCQjRCMzlCMEFcIlxuICAgICAgfSxcbiAgICAgIFwibWVzc2FnZVRpbWVzdGFtcFwiOiAxNzE4NzMwMTA1XG4gICAgfSxcbiAgICB7XG4gICAgICBcImtleVwiOiB7XG4gICAgICAgIFwicmVtb3RlSmlkXCI6IFwiOTIzMDE1MDUxMjMyQHMud2hhdHNhcHAubmV0XCIsXG4gICAgICAgIFwiZnJvbU1lXCI6IHRydWUsXG4gICAgICAgIFwiaWRcIjogXCI3Q0IwRjU3RkE4MTZBNkE3RUE4QUJDRTQ5RDNGNUIwRlwiXG4gICAgICB9LFxuICAgICAgXCJtZXNzYWdlVGltZXN0YW1wXCI6IDE3MTg3MzAxMDVcbiAgICB9LFxuICAgIHtcbiAgICAgIFwia2V5XCI6IHtcbiAgICAgICAgXCJyZW1vdGVKaWRcIjogXCI5MjMwMTUwNTEyMzJAcy53aGF0c2FwcC5uZXRcIixcbiAgICAgICAgXCJmcm9tTWVcIjogdHJ1ZSxcbiAgICAgICAgXCJpZFwiOiBcIkQ2ODUwMDZFQjZFNTVDODgyMzI0MzNFMTgyRDQyNjdFXCJcbiAgICAgIH0sXG4gICAgICBcIm1lc3NhZ2VUaW1lc3RhbXBcIjogMTcxODczMDEwOVxuICAgIH0sXG4gICAge1xuICAgICAgXCJrZXlcIjoge1xuICAgICAgICBcInJlbW90ZUppZFwiOiBcIjkyMzAxNTA1MTIzMkBzLndoYXRzYXBwLm5ldFwiLFxuICAgICAgICBcImZyb21NZVwiOiB0cnVlLFxuICAgICAgICBcImlkXCI6IFwiQUQzMDFDRUEwNUY0NDFGQUQ3MDJEOTA2OTZBMjc1QzhcIlxuICAgICAgfSxcbiAgICAgIFwibWVzc2FnZVRpbWVzdGFtcFwiOiAxNzE4NzMwMTEwXG4gICAgfVxuICBdLFxuICBcIm5leHRQcmVLZXlJZFwiOiAzMSxcbiAgXCJmaXJzdFVudXBsb2FkZWRQcmVLZXlJZFwiOiAzMSxcbiAgXCJhY2NvdW50U3luY0NvdW50ZXJcIjogMSxcbiAgXCJhY2NvdW50U2V0dGluZ3NcIjoge1xuICAgIFwidW5hcmNoaXZlQ2hhdHNcIjogZmFsc2VcbiAgfSxcbiAgXCJkZXZpY2VJZFwiOiBcIktrU0NXdXJJUzdxdmdVclJ5a0tIU1FcIixcbiAgXCJwaG9uZUlkXCI6IFwiYjQ2Njk2ZWItZWIwYi00MjczLThhNmItZGUzYWQyMzNiYzliXCIsXG4gIFwiaWRlbnRpdHlJZFwiOiB7XG4gICAgXCJ0eXBlXCI6IFwiQnVmZmVyXCIsXG4gICAgXCJkYXRhXCI6IFtcbiAgICAgIDEwMixcbiAgICAgIDkzLFxuICAgICAgMTczLFxuICAgICAgMTQyLFxuICAgICAgNTksXG4gICAgICAyNTIsXG4gICAgICAyMTIsXG4gICAgICAxMzAsXG4gICAgICAxMjAsXG4gICAgICAxODUsXG4gICAgICAyMzQsXG4gICAgICAyMDMsXG4gICAgICAyMSxcbiAgICAgIDEyOSxcbiAgICAgIDEyOSxcbiAgICAgIDEwOSxcbiAgICAgIDQ1LFxuICAgICAgMTY1LFxuICAgICAgMjA4LFxuICAgICAgMjAyXG4gICAgXVxuICB9LFxuICBcInJlZ2lzdGVyZWRcIjogdHJ1ZSxcbiAgXCJiYWNrdXBUb2tlblwiOiB7XG4gICAgXCJ0eXBlXCI6IFwiQnVmZmVyXCIsXG4gICAgXCJkYXRhXCI6IFtcbiAgICAgIDE5NyxcbiAgICAgIDMyLFxuICAgICAgMTI0LFxuICAgICAgMTI3LFxuICAgICAgMTIzLFxuICAgICAgMTkzLFxuICAgICAgMTA4LFxuICAgICAgMjEsXG4gICAgICA0MixcbiAgICAgIDcwLFxuICAgICAgMTUyLFxuICAgICAgMTg5LFxuICAgICAgMjI4LFxuICAgICAgODIsXG4gICAgICAxNjIsXG4gICAgICA2NCxcbiAgICAgIDY1LFxuICAgICAgMTM1LFxuICAgICAgOTMsXG4gICAgICAyNDlcbiAgICBdXG4gIH0sXG4gIFwicmVnaXN0cmF0aW9uXCI6IHt9LFxuICBcInBhaXJpbmdDb2RlXCI6IFwiVEUxS1o3MlpcIixcbiAgXCJtZVwiOiB7XG4gICAgXCJpZFwiOiBcIjkyMzAxNTA1MTIzMjo2QHMud2hhdHNhcHAubmV0XCIsXG4gICAgXCJsaWRcIjogXCIxNDg5NjI4NzA4NjIwMjI6NkBsaWRcIixcbiAgICBcIm5hbWVcIjogXCJOdWxcIlxuICB9LFxuICBcImFjY291bnRcIjoge1xuICAgIFwiZGV0YWlsc1wiOiBcIkNOV1F3YlVCRVBUNnhyTUdHQUVnQUNnQVwiLFxuICAgIFwiYWNjb3VudFNpZ25hdHVyZUtleVwiOiBcImZWamIzLzdVZ3R6MGJPZFJKb05odld0QzhTMzFUb1RYR3AzZ0NDd1VtMGs9XCIsXG4gICAgXCJhY2NvdW50U2lnbmF0dXJlXCI6IFwiWVQzblFKSHVjcFU1VnYzQ2lOekt5MURSdlFkKzVJcmxJTTd0Sm4xY1JTdmhIVzlOZHJXcU1tMGlJL1FrS2hXNEQyd0d5aW5jSVdkZE4wd1R5bW5HQ2c9PVwiLFxuICAgIFwiZGV2aWNlU2lnbmF0dXJlXCI6IFwia2VOZm9VL2NLWm96MXhhUWpUQStIQityekZFMUowa21mRGg3S3VWem03aVNjWWRtY1RMSEFkSTBpM0dZenI4SXBSRWdZUitDajJyL051cFBGT3B5Z2c9PVwiXG4gIH0sXG4gIFwic2lnbmFsSWRlbnRpdGllc1wiOiBbXG4gICAge1xuICAgICAgXCJpZGVudGlmaWVyXCI6IHtcbiAgICAgICAgXCJuYW1lXCI6IFwiOTIzMDE1MDUxMjMyOjZAcy53aGF0c2FwcC5uZXRcIixcbiAgICAgICAgXCJkZXZpY2VJZFwiOiAwXG4gICAgICB9LFxuICAgICAgXCJpZGVudGlmaWVyS2V5XCI6IHtcbiAgICAgICAgXCJ0eXBlXCI6IFwiQnVmZmVyXCIsXG4gICAgICAgIFwiZGF0YVwiOiBbXG4gICAgICAgICAgNSxcbiAgICAgICAgICAxMjUsXG4gICAgICAgICAgODgsXG4gICAgICAgICAgMjE5LFxuICAgICAgICAgIDIyMyxcbiAgICAgICAgICAyNTQsXG4gICAgICAgICAgMjEyLFxuICAgICAgICAgIDEzMCxcbiAgICAgICAgICAyMjAsXG4gICAgICAgICAgMjQ0LFxuICAgICAgICAgIDEwOCxcbiAgICAgICAgICAyMzEsXG4gICAgICAgICAgODEsXG4gICAgICAgICAgMzgsXG4gICAgICAgICAgMTMxLFxuICAgICAgICAgIDk3LFxuICAgICAgICAgIDE4OSxcbiAgICAgICAgICAxMDcsXG4gICAgICAgICAgNjYsXG4gICAgICAgICAgMjQxLFxuICAgICAgICAgIDQ1LFxuICAgICAgICAgIDI0NSxcbiAgICAgICAgICA3OCxcbiAgICAgICAgICAxMzIsXG4gICAgICAgICAgMjE1LFxuICAgICAgICAgIDI2LFxuICAgICAgICAgIDE1NyxcbiAgICAgICAgICAyMjQsXG4gICAgICAgICAgOCxcbiAgICAgICAgICA0NCxcbiAgICAgICAgICAyMCxcbiAgICAgICAgICAxNTUsXG4gICAgICAgICAgNzNcbiAgICAgICAgXVxuICAgICAgfVxuICAgIH1cbiAgXSxcbiAgXCJwbGF0Zm9ybVwiOiBcImFuZHJvaWRcIixcbiAgXCJsYXN0QWNjb3VudFN5bmNUaW1lc3RhbXBcIjogMTcxODczMDEwMyxcbiAgXCJteUFwcFN0YXRlS2V5SWRcIjogXCJBQUFBQUFkYVwiXG59IiwKICAiYXBwLXN0YXRlLXN5bmMta2V5LUFBQUFBQWRhLmpzb24iOiAie1wia2V5RGF0YVwiOlwiTE8zUUZhOGZpTW1PZHVLZ0ZJZVBzSjdMa2FRZnlnb3ZHc0FYUmljL3h5Zz1cIixcImZpbmdlcnByaW50XCI6e1wicmF3SWRcIjozODA2NTE2MDUsXCJjdXJyZW50SW5kZXhcIjoxLFwiZGV2aWNlSW5kZXhlc1wiOlswLDFdfSxcInRpbWVzdGFtcFwiOlwiMTcxODczMDEwNTE1M1wifSIKfQ=="  // PUT your SESSION_ID 


module.exports = {

  menu: process.env.MENU || "", /**  Available @MENU @Schemes 1: Aztec_Md, 2: A17_Md, 3: Nafla-Md Default ---------- If Not Choose then it Randomely Pic One Of Them Each time **/

  HANDLERS: process.env.PREFIX  || "-",
  BRANCH  : process.env.BRANCH  || "main",
  VERSION : process.env.VERSION || "1.3.7",
  caption : global.caption || "ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴀʜᴍᴇᴅ" , // ```『 ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴀʜᴍᴇᴅ 』```", //*『ᴄᴏɴᴛᴀᴄᴛ: • ᴀʜᴍᴇᴅ』*\n https://wa.link/jc0bfl"),
 
  author : process.env.PACK_AUTHER|| "",
  packname: process.env.PACK_NAME || "",
  botname : process.env.BOT_NAME  || "ɴᴀꜰʟᴀ-ᴍᴅ",
  ownername:process.env.OWNER_NAME|| "ᴀʜᴍᴇᴅ🖤",


  errorChat : process.env.ERROR_CHAT || "",
  KOYEB_API : process.env.KOYEB_API  || "false",

  REMOVE_BG_KEY : process.env.REMOVE_BG_KEY  || "",
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || "",
  HEROKU_API_KEY: process.env.HEROKU_API_KEY || "",
  HEROKU_APP_NAME:process.env.HEROKU_APP_NAME|| "",
  antilink_values:process.env.ANTILINK_VALUES|| "all",
  HEROKU: process.env.HEROKU_APP_NAME && process.env.HEROKU_API_KEY,


  WORKTYPE: process.env.WORKTYPE || process.env.MODE|| "private",
  LANG: ( process.env.THEME ||  "SUHAIL"  ).toUpperCase(),



};



global.ELEVENLAB_API_KEY = process.env.ELEVENLAB_API_KEY || "55843ea8ef94a73920e36fc14cbc6bb1";
global.aitts_Voice_Id = process.env.AITTS_ID|| "37";





















global.rank = "updated"
global.isMongodb = false; 
let file = require.resolve(__filename)
fs.watchFile(file, () => { fs.unwatchFile(file);console.log(`Update'${__filename}'`);delete require.cache[file];	require(file); })
 

// ========================= [ Disables in V.1.2.8 ] ===============================\\  
  //style : process.env.STYLE || "2",  // put '1' & "2" here to check bot styles
  //readmessage:process.env.READ_MESSAGE|| "false",
  //warncount: process.env.WARN_COUNT || 3,
  //userImages:process.env.USER_IMAGES|| "text",  // SET IMAGE AND VIDEO URL FOR BOT MENUS 
  //disablepm: process.env.DISABLE_PM || "false",
  //MsgsInLog: process.env.MSGS_IN_LOG|| "false", // "true"  to see messages , "log" to open logs , "false" to hide logs messages
  //readcmds:process.env.READ_COMMANDS|| "false", 
  //alwaysonline:process.env.WAPRESENCE|| "unavailable", // 'unavailable' | 'online' | 'composing' | 'recording' | 'paused'
  //read_status: process.env.AUTO_READ_STATUS || "false",
  //save_status: process.env.AUTO_SAVE_STATUS || "false",
  //aitts_Voice_Id : process.env.AITTS_ID || "37",
  //ELEVENLAB_API_KEY: process.env.ELEVENLAB_API_KEY  || "",
